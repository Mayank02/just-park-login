const assert = require("assert");

const sockMerchant = (inputCount, input) => {
  const frequencyMap = {};
  let pairs = 0;
  input.split(" ").forEach((item) => {
    if (frequencyMap[item]) {
      frequencyMap[item]++;
    } else {
      frequencyMap[item] = 1;
    }
    if (frequencyMap[item] === 2) {
      pairs++;
      frequencyMap[item] = 0;
    }
  });
  return pairs;
};

const testData = [
  { inputCount: 9, input: "10 20 20 10 10 30 50 10 20", expected: 3 },
  { inputCount: 15, input: "6 5 2 3 5 2 2 1 1 5 1 3 3 3 5", expected: 6 },
  {
    inputCount: 20,
    input: "4 5 5 5 6 6 4 1 4 4 3 6 6 3 6 1 4 5 5 5",
    expected: 9,
  },
  { inputCount: 9, input: "1 2 3 4 5 6 7 8 9", expected: 0 },
  { inputCount: 11, input: "1 1 1 1 1 1 1 1 1 1 1", expected: 5 },
];

const testWithData = (inputCount, input, expected) => {
  describe(`Input: ${input}, Expected: ${expected}`, function () {
    it("should calculate the correct result", function () {
      assert.equal(sockMerchant(inputCount, input), expected);
    });
  });
};

describe("sockMerchant tests", function () {
  testData.forEach(({ inputCount, input, expected }) => {
    testWithData(inputCount, input, expected);
  });
});
