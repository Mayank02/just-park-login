JP Frontend Task

Installation

`yarn`

Running the test suite

`yarn run test`

Instructions

1. Read the task instructions thoroughly located in the instructions pdf in this directory.
2. You have 30 minutes to implement.
2. Complete the TODO's located in test/test.js - implement the `sockMerchant` function so that the tests pass,
   and add any other tests you wish to the test cases, based on the test instructions.

